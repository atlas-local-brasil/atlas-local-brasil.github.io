(() => {
    'use strict';

    const toggle = document.querySelector('[data-nav-toggle]');
    const nav = document.querySelector('[data-primary-nav]');

    const closeMenu = () => {
        if (!toggle || !nav) return;
        nav.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Abrir menu');
        document.body.classList.remove('nav-open');
    };

    if (toggle && nav) {
        toggle.addEventListener('click', () => {
            const open = nav.classList.toggle('is-open');
            toggle.setAttribute('aria-expanded', String(open));
            toggle.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
            document.body.classList.toggle('nav-open', open);
        });

        nav.querySelectorAll('a').forEach((link) => {
            link.addEventListener('click', closeMenu);
        });

        document.addEventListener('click', (event) => {
            if (!nav.contains(event.target) && !toggle.contains(event.target)) {
                closeMenu();
            }
        });

        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') closeMenu();
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth > 1040) closeMenu();
        });
    }


    const searchApp = document.querySelector('[data-search-app]');
    if (searchApp) {
        const form = searchApp.querySelector('[data-search-form]');
        const input = searchApp.querySelector('[data-search-input]');
        const output = searchApp.querySelector('[data-search-output]');
        const params = new URLSearchParams(window.location.search);
        const initial = (params.get('q') || '').trim().slice(0, 100);
        if (input) input.value = initial;

        const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[char]));
        const normalize = (value) => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

        const renderSearch = async (query) => {
            if (!output) return;
            if (!query) {
                output.innerHTML = '<div class="empty-state"><span class="empty-icon">⌕</span><h2>Digite um termo para começar</h2><p>Você pode pesquisar por empresa, serviço, cidade ou assunto.</p></div>';
                return;
            }
            try {
                const response = await fetch('/assets/data/search-index.json', {cache: 'no-cache'});
                if (!response.ok) throw new Error('Falha ao carregar índice');
                const items = await response.json();
                const needle = normalize(query);
                const results = items.filter((item) => normalize([item.title,item.description,item.meta,item.keywords].join(' ')).includes(needle));
                const cards = results.map((item) => `<article class="search-result"><small>${escapeHtml(item.type)}${item.meta ? ' • '+escapeHtml(item.meta) : ''}</small><h2><a href="${escapeHtml(item.url)}">${escapeHtml(item.title)}</a></h2><p>${escapeHtml(item.description)}</p><a class="search-result-link" href="${escapeHtml(item.url)}">Acessar página →</a></article>`).join('');
                output.innerHTML = `<div class="search-summary"><strong>${results.length}</strong><span>resultado${results.length === 1 ? '' : 's'} para “${escapeHtml(query)}”</span></div>${results.length ? `<div class="search-results" aria-live="polite">${cards}</div>` : '<div class="empty-state"><span class="empty-icon">⌕</span><h2>Nenhum resultado encontrado</h2><p>Tente um serviço, uma cidade, empresa ou assunto.</p></div>'}`;
            } catch (error) {
                output.innerHTML = '<div class="empty-state"><h2>Pesquisa indisponível</h2><p>Atualize a página e tente novamente.</p></div>';
            }
        };
        if (form) form.addEventListener('submit', (event) => {
            event.preventDefault();
            const query = (input?.value || '').trim().slice(0, 100);
            const url = new URL(window.location.href);
            query ? url.searchParams.set('q', query) : url.searchParams.delete('q');
            window.history.replaceState({}, '', url);
            renderSearch(query);
        });
        renderSearch(initial);
    }

    document.querySelectorAll('[data-current-year]').forEach((element) => {
        element.textContent = String(new Date().getFullYear());
    });
})();
